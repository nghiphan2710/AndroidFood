package Model;

public class Commen {
    public static User currentUser;
}
